package com.zxl.mvvmdemo;


import android.os.Bundle;
import android.view.View;

import com.zxl.mvvmdemo.databinding.ActivityMainBinding;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding mainBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainBinding = DataBindingUtil.setContentView(this, R.layout.activity_main);
        User user = new User("李二牛","15845698752");
        user.setUrl("http://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTIP7Xl7FtM5RPcqL1hQVzO6ffNtmoAKQfOJibsT04Nl5fa2QYI4Yc68QgJTlxcjAjnwHIo3Q5LX0tA/132");
//"http://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTIP7Xl7FtM5RPcqL1hQVzO6ffNtmoAKQfOJibsT04Nl5fa2QYI4Yc68QgJTlxcjAjnwHIo3Q5LX0tA/132"
        mainBinding.setUser(user);
    }
    public void click(View view){
        mainBinding.getUser().setName("hahhaha");
//        if (mainBinding.getUser() == null){
//            User user = new User("李二牛","15845698752");
//            mainBinding.setUser(user);
//        }else {
//            mainBinding.setUser(null);
//        }
    }
}
